package com.konnectbox.controller;

import java.util.Base64;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.konnectbox.model.UserRQModel;
import com.konnectbox.model.JwtResponse;
import com.konnectbox.service.JwtUserDetailsService;
import com.konnectbox.util.JwtTokenUtil;

@RestController
@CrossOrigin
public class UserController {


	@Autowired
	private JwtTokenUtil jwtTokenUtil;
	
	@Autowired
	private JwtUserDetailsService jwtUserDetailsService;

	@PostMapping(value = "/authenticate")
	public ResponseEntity<?> createAuthenticationToken(@RequestBody UserRQModel authenticationRequest)
			throws Exception {

		final UserDetails userDetails=	authenticate(authenticationRequest.getUsername(), authenticationRequest.getPassword());
		final String token = jwtTokenUtil.generateToken(userDetails);

		return ResponseEntity.ok(new JwtResponse(token));
	}

	private UserDetails authenticate(String username, String password) throws Exception {
		Objects.requireNonNull(username);
		Objects.requireNonNull(password);

		try {
			final UserDetails userDetails = jwtUserDetailsService.loadUserByUsername(username);
			String encodedString = Base64.getEncoder().encodeToString(password.getBytes());
			if(userDetails.getPassword().equals(encodedString)) {
				return userDetails;
			}
			//authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
		} catch (DisabledException e) {
			throw new Exception("USER_DISABLED", e);
		} catch (BadCredentialsException e) {
			throw new Exception("INVALID_CREDENTIALS", e);
		}
		 return null;
	}
	@PostMapping("/signUp")
	public ResponseEntity<?> creatUser(@RequestBody UserRQModel authenticationRequest) throws Exception{
		String token="";
		 UserDetails userDetails = null; 
		if(!jwtUserDetailsService.ifUserExists(authenticationRequest.getUsername())) {
			userDetails=	jwtUserDetailsService.createUser(authenticationRequest.getUsername(), authenticationRequest.getPassword());
			  token = jwtTokenUtil.generateToken(userDetails);
			
		}else {
			throw new Exception("User already exists with username "+ authenticationRequest.getUsername() +"please try another username");
		}
		
		return ResponseEntity.ok(new JwtResponse(token));
	}
}
