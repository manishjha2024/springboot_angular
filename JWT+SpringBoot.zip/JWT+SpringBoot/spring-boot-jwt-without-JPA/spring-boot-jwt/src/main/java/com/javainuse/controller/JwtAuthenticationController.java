package com.javainuse.controller;

import java.util.Base64;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.javainuse.config.JwtTokenUtil;
import com.javainuse.model.JwtRequest;
import com.javainuse.model.JwtResponse;
import com.javainuse.service.JwtUserDetailsService;

@RestController
@CrossOrigin
public class JwtAuthenticationController {

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private UserDetailsService jwtInMemoryUserDetailsService;
	
	@Autowired
	private JwtUserDetailsService jwtUserDetailsService;

	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtRequest authenticationRequest)
			throws Exception {

		final UserDetails userDetails=	authenticate(authenticationRequest.getUsername(), authenticationRequest.getPassword());
		final String token = jwtTokenUtil.generateToken(userDetails);

		return ResponseEntity.ok(new JwtResponse(token));
	}

	private UserDetails authenticate(String username, String password) throws Exception {
		Objects.requireNonNull(username);
		Objects.requireNonNull(password);

		try {
			final UserDetails userDetails = jwtUserDetailsService.loadUserByUsername(username);
			String encodedString = Base64.getEncoder().encodeToString(password.getBytes());
			if(userDetails.getPassword().equals(encodedString)) {
				return userDetails;
			}
			//authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
		} catch (DisabledException e) {
			throw new Exception("USER_DISABLED", e);
		} catch (BadCredentialsException e) {
			throw new Exception("INVALID_CREDENTIALS", e);
		}
		 return null;
	}
	@PostMapping("/signUp")
	public ResponseEntity<?> creatUser(@RequestBody JwtRequest authenticationRequest) throws Exception{
		String token="";
		 UserDetails userDetails = null; 
		if(!jwtUserDetailsService.ifUserExists(authenticationRequest.getUsername())) {
			userDetails=	jwtUserDetailsService.createUser(authenticationRequest.getUsername(), authenticationRequest.getPassword());
			  token = jwtTokenUtil.generateToken(userDetails);
			
		}else {
			throw new Exception("User already exists with username "+ authenticationRequest.getUsername() +"please try another username");
		}
		
		return ResponseEntity.ok(new JwtResponse(token));
	}
}
